% PROLIFIC - PROfile LIkelihood based in FIbonaCci search
% Version 0.99 (R2019b) June 2020
