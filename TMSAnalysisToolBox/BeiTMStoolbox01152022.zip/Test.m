%% assume SLMF is the first algorithm of the pre-processing module


if app.SLMFoverRideMark == 1  % if hit override
    %% call the mouse, find the override onset and offset
    
    currPt = app.UIAxes.CurrentPoint;
    
    app.overRideInd = [app.overRideInd,currPt(1,1)];
    overRideOnset = app.overRideInd(1);           % overRideOnset and overRideOffset here are time not indext, need to convert to index
    if length(app.overRideInd) == 2
        overRideOffset = app.overRideInd(2);
        app.UIFigure.Pointer = 'arrow';
    end
    if length(app.overRideInd) > 2  % in case two more than two clicks occur
        msgbox('please re-override')
    end
    
    app.SLMFlabel.Visible = 0;
    % plot
    %hold(app.UIAxes,'on');
    if length(app.overRideInd) == 1  % the first line is the onset
        app.onsetLine = xline(app.UIAxes,overRideOnset,'r','LineStyle','--',"LineWidth",2,'DisplayName', 'overrideOnset');
    end
    if length(app.overRideInd)>=2 % the second line is the offset
        app.offsetLine = xline(app.UIAxes,overRideOffset,'b','LineStyle','--',"LineWidth",2,'DisplayName', 'overrideOffset');
    end
    hold(app.UIAxes,'off');
    legend(app.UIAxes)
    
    
    %%
    pause(0.5)
    
    msgbox ('Please define the MUAP range within the post MEP range')
    
    currPt = app.UIAxes.CurrentPoint;
    
    app.overRideInd = [app.overRideInd,currPt(1,1)];
    overRideOnset = app.overRideInd(1);           % overRideOnset and overRideOffset here are time not indext, need to convert to index
    if length(app.overRideInd) == 2
        overRideOffset = app.overRideInd(2);
        app.UIFigure.Pointer = 'arrow';
    end
    if length(app.overRideInd) > 2  % in case two more than two clicks occur
        msgbox('please re-override')
    end
    
    app.SLMFlabel.Visible = 0;
    % plot
    %hold(app.UIAxes,'on');
    if length(app.overRideInd) == 1  % the first line is the onset
        app.onsetLine = xline(app.UIAxes,overRideOnset,'r','LineStyle','--',"LineWidth",1,'DisplayName', 'InitMEPonset');
    end
    if length(app.overRideInd)>=2 % the second line is the offset
        app.offsetLine = xline(app.UIAxes,overRideOffset,'b','LineStyle','--',"LineWidth",1,'DisplayName', 'InitMEPoffset');
    end
    hold(app.UIAxes,'off');
    legend(app.UIAxes)
    
    
end



%% extract all data within the period
if app.SLMFCheckBox.Value == true  % if hit override
    data = num2cell(app.UnprocessedData,2);          %% !!!!!!!! may need change if it can not be the first one in pre-processing module
    overRideOnset = app.overRideInd(1);           % overRideOnset and overRideOffset here are time not index, need to convert to index
    overRideOffset = app.overRideInd(2);
    onsetInd =  find(SPTime>=overRideOnset);
    offsetInd = find(SPTime>=overRideOffset);
    overRideData = data(:,onsetInd:offsetInd);    %% !!!!! or data(onsetInd:offsetInd,:)
end

%% Process the data




%%
